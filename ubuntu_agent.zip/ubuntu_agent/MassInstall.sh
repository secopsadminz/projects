#!/bin/bash

OS=$(uname -s)

if [ "$OS" == "Darwin" ]; then
  if ! command -v brew &> /dev/null; then
      echo "Homebrew not found. Installing Homebrew..."
      /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
  fi
  if ! command -v sshpass &> /dev/null; then
      echo "sshpass not found. Installing sshpass..."
      brew install https://raw.githubusercontent.com/kadwanev/bigboybrew/master/Library/Formula/sshpass.rb
  fi
elif [ "$OS" == "Linux" ]; then
  if command -v apt-get &> /dev/null; then
    if ! dpkg -s sshpass &> /dev/null; then
      echo "sshpass not found. Installing sshpass..."
      sudo apt-get update
      sudo apt-get install -y sshpass
    fi
  elif command -v yum &> /dev/null; then
    if ! rpm -q sshpass &> /dev/null; then
      echo "sshpass not found. Installing sshpass..."
      sudo yum install -y epel-release
      sudo yum install -y sshpass
    fi
  else
    echo "Unsupported Linux distribution"
    exit 1
  fi
else
  echo "Unsupported operating system"
  exit 1
fi

SERVERS=$(cat server_list.txt)
GREEN=$(tput setaf 2)
RESET=$(tput sgr0)
KEYS=$(cat key_list.txt)

while IFS=$'\t' read -r SERVER KEY; do
    IP=$(echo $SERVER | cut -d',' -f1)
    PASSWORD=$(echo $SERVER | cut -d',' -f2)
    echo "$IP $KEY"
    echo -e "task performing on server $IP with key $KEY"
    sshpass -p $PASSWORD scp Anamo.deb $IP:/tmp
    # checking is bun2zip is installed
    if sshpass -p $PASSWORD ssh $IP "dpkg -s bzip2 >/dev/null 2>&1"; then
        echo "bzip2 is already installed on $IP"
    else
        sshpass -p $PASSWORD ssh $IP "sudo apt-get install -y bzip2"
    fi
    sshpass -p $PASSWORD ssh -o ConnectTimeout=600 $IP "sudo dpkg -i /tmp/Anamo.deb && sudo /Anamo -a INSTALL && printf 'yes\nanamo@anamo.com\nDrake\nIT\nIT\n478938298\n$KEY\n' | /Anamo -a START " < /dev/null || true
    echo -e "${GREEN}Done installing requirements and running on server $IP${RESET}"
    # Perform your desired task with $a and $b
done < <(paste server_list.txt key_list.txt)