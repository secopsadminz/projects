process to run the package 

step 1: depackage/intall the file using "sudo dpkg -i Anamo.deb"

step 2: run "sudo /Anamo -a INSTALL" to install  the package requirements

STEP 3: run "sudo /Anamo -a START" to start the agent or "sudo /Anamo -a Vulns" to only check for vulnerabilities

if there's a neeed to run the agent again just run the below command from any path on the system 

sudo /Anamo -a START

from any where on the system 

setting up the systemCtl: 
then you setup the system ctl by using the below commands 

sudo systemctl daemon-reload
sudo systemctl enable Anamo.service
sudo systemctl enable AnamoVulns.service

#sudo systemctl is-enabled Anamo.service  #this command tells you if it has been activated
sudo systemctl start Anamo.service
sudo systemctl start AnamoVulns.service


to remove run 

sudo apt-get remove AnamoPackage

sudo systemctl disable Anamo.service
sudo systemctl disable AnamoVulns.service
sudo systemctl daemon-reload